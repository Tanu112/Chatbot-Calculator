let chatlog = document.getElementById('chatlog');
let input = document.getElementById('message-input');

function sendMessage() {
  let message = input.value;
  input.value = '';
  if (message=='hi' || message=='hello' || message=='hey' || message=='Hello' || message=='Hey' || message=='Hi'){
    fetch('/calculate', {
      method: 'POST',
      body: new URLSearchParams({
        message: message
      })
    })
    .then(response => response.text())
    .then(result => {
      addMessage(message, 'user');
      addMessage('What operation to perform', 'chatbot');
    })
    .catch(error => {
      console.error('Error:', error);
    });
  }
  else{
    fetch('/calculate', {
      method: 'POST',
      body: new URLSearchParams({
        message: message
      })
    })
    .then(response => response.text())
    .then(result => {
      addMessage(message, 'user');
      addMessage(result, 'chatbot');
    })
    .catch(error => {
      console.error('Error:', error);
    });
  }
}

function addMessage(message, sender) {
  let messageBox = document.createElement('div');
  messageBox.classList.add('message-box', sender);
  messageBox.innerHTML = message;

  chatlog.appendChild(messageBox);
  chatlog.scrollTop = chatlog.scrollHeight;
}
