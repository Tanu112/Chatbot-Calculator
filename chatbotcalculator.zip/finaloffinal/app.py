from flask import Flask, render_template, request
import math

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    message = request.form['message']
    result = str(eval(message))
    return result

if __name__ == '__main__':
    app.run(debug=True)
